#requires -Version 5.1
[CmdletBinding()]
param(
  [Parameter(Mandatory=$true)][string]$OutputDirectory
)
$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest
if ($env:OS -ne "Windows_NT") { throw "This helper runs only on Windows." }
$subject = "CN=Bookie Local Gateway TEST ONLY"
$now = [DateTime]::UtcNow
$existing = @(Get-ChildItem Cert:\CurrentUser\My | Where-Object { $_.Subject -eq $subject })
if ($existing.Count -gt 0) { throw "A TEST ONLY certificate already exists; remove the exact thumbprint before retrying." }
foreach ($storeName in "Root","TrustedPublisher") {
  $probe = New-Object Security.Cryptography.X509Certificates.X509Store($storeName,"CurrentUser")
  $probe.Open("ReadOnly")
  try {
    if (@($probe.Certificates | Where-Object Subject -eq $subject).Count -gt 0) { throw "A TEST ONLY certificate already exists in CurrentUser\$storeName." }
  } finally { $probe.Close() }
}
New-Item -ItemType Directory -Force $OutputDirectory | Out-Null
$output = (Resolve-Path $OutputDirectory).Path
$cerPath = Join-Path $output "Bookie-Local-Gateway-TEST-ONLY.cer"
$descriptorPath = Join-Path $output "Bookie-Local-Gateway-TEST-ONLY.json"
if ((Test-Path $cerPath) -or (Test-Path $descriptorPath)) { throw "Refusing to overwrite existing test certificate output." }
$cert = New-SelfSignedCertificate -Type Custom -Subject $subject -CertStoreLocation Cert:\CurrentUser\My `
  -KeyAlgorithm RSA -KeyLength 3072 -HashAlgorithm SHA256 -KeyExportPolicy NonExportable `
  -NotAfter $now.AddDays(30) -KeyUsage DigitalSignature `
  -TextExtension @("2.5.29.37={text}1.3.6.1.5.5.7.3.3")
if (-not $cert.HasPrivateKey -or $cert.Subject -ne $subject -or $cert.Issuer -ne $subject -or
    $cert.PublicKey.Key.KeySize -lt 3072 -or $cert.SignatureAlgorithm.Value -ne "1.2.840.113549.1.1.11" -or
    -not ($cert.PrivateKey -is [Security.Cryptography.RSACng]) -or
    $cert.PrivateKey.Key.ExportPolicy.ToString() -ne "None") { throw "Created certificate prerequisites failed." }
Export-Certificate -Cert $cert -FilePath $cerPath -Type CERT | Out-Null
$publicCert = New-Object Security.Cryptography.X509Certificates.X509Certificate2(,$cert.RawData)
foreach ($storeName in "Root","TrustedPublisher") {
  $probe = New-Object Security.Cryptography.X509Certificates.X509Store($storeName,"CurrentUser")
  $probe.Open("ReadOnly")
  try {
    if (@($probe.Certificates | Where-Object Thumbprint -eq $cert.Thumbprint).Count -gt 0) { throw "Certificate already exists in CurrentUser\$storeName." }
  } finally { $probe.Close() }
}
foreach ($storeName in "Root","TrustedPublisher") {
  $store = New-Object Security.Cryptography.X509Certificates.X509Store($storeName,"CurrentUser")
  $store.Open("ReadWrite")
  try {
    $store.Add($publicCert)
  } finally { $store.Close() }
}
$checks = @(
  @{Path="Cert:\CurrentUser\My"; Private=$true},
  @{Path="Cert:\CurrentUser\Root"; Private=$false},
  @{Path="Cert:\CurrentUser\TrustedPublisher"; Private=$false})
foreach ($check in $checks) {
  $found = @(Get-ChildItem $check.Path | Where-Object Thumbprint -eq $cert.Thumbprint)
  if ($found.Count -ne 1) { throw "Exact certificate verification failed in $($check.Path)." }
  if ($check.Private -and -not $found[0].HasPrivateKey) { throw "CurrentUser\My certificate has no private key." }
  if (-not $check.Private -and $found[0].HasPrivateKey) { throw "Public trust store unexpectedly contains a private key." }
}
$eku = @($cert.Extensions | Where-Object Oid.Value -eq "2.5.29.37" |
  ForEach-Object { $_.EnhancedKeyUsages } | Where-Object Value -eq "1.3.6.1.5.5.7.3.3")
if ($eku.Count -eq 0 -or $cert.NotAfter.ToUniversalTime() -le $now -or
    ($cert.NotAfter.ToUniversalTime() - $cert.NotBefore.ToUniversalTime()).TotalDays -gt 31) { throw "Certificate EKU/validity/profile verification failed." }
if (-not (Get-Command Get-AuthenticodeSignature -ErrorAction SilentlyContinue)) { throw "Authenticode verification prerequisite is unavailable." }
$descriptor = [ordered]@{
  thumbprint=$cert.Thumbprint; subject=$cert.Subject; created=$cert.NotBefore.ToUniversalTime().ToString("o")
  expires=$cert.NotAfter.ToUniversalTime().ToString("o"); createdDisplay=$cert.NotBefore.ToString("dd.MM.yyyy")
  expiresDisplay=$cert.NotAfter.ToString("dd.MM.yyyy"); releaseChannel="test"; productionAllowed=$false
}
$descriptor | ConvertTo-Json -Depth 4 | Set-Content $descriptorPath -Encoding UTF8
Write-Host "TEST ONLY certificate thumbprint: $($cert.Thumbprint)"