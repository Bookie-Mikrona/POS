#requires -RunAsAdministrator
#requires -Version 5.1
[CmdletBinding()]
param(
  [Parameter(Mandatory=$true)][string]$PreviousPackagePath,
  [Parameter(Mandatory=$true)][string]$NewPackagePath,
  [Parameter(Mandatory=$true)][string]$ExpectedPreviousSignerThumbprint,
  [Parameter(Mandatory=$true)][string]$ExpectedNewSignerThumbprint,
  [string]$InstallPath = "$env:ProgramFiles\BookieFiscalService",
  [int]$Port = 17831,
  [switch]$ConfirmFencedLab,
  [string]$EvidencePath = "$PSScriptRoot\windows-upgrade-evidence.json"
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest
$checks = [System.Collections.Generic.List[object]]::new()
$release = [ordered]@{previous="unknown";new="unknown"}
$testEnvironmentAdded = $false
$trustEntriesAdded = [System.Collections.Generic.List[object]]::new()
$serviceRegistryPath = "HKLM:\SYSTEM\CurrentControlSet\Services\BookieFiscalService"
$dataPath = Join-Path $env:ProgramData "BookieFiscal"
$backupPath = Join-Path $env:ProgramData "BookieFiscal-Backups"
$adminTokenPath = Join-Path $dataPath "admin-token.txt"
$workRoot = Join-Path $env:TEMP ("BookieGatewayUpgradeVerification-" + [Guid]::NewGuid().ToString("N"))

function Safe-Detail([string]$Value) {
  $safe = [string]$Value
  foreach ($root in @($env:ProgramData,$env:ProgramFiles,$env:TEMP)) {
    if ($root) { $safe = $safe -replace [regex]::Escape($root), "[redacted-root]" }
  }
  return $safe
}
function Add-Check([string]$Name,[bool]$Pass,[string]$Detail) {
  $checks.Add([ordered]@{name=$Name;status=$(if($Pass){"confirmed"}else{"failed"});detail=(Safe-Detail $Detail)})
  if (-not $Pass) { throw "$Name failed: $Detail" }
}
function Write-Evidence([string]$Outcome,[string]$Failure = "") {
  $confirmed = @($checks | Where-Object { $_.status -eq "confirmed" }).Count
  [ordered]@{
    generatedUtc=[DateTime]::UtcNow.ToString("o")
    outcome=$Outcome
    summary="Windows gateway upgrade verification: $confirmed/$($checks.Count) checks confirmed."
    releases=$release
    excludedVolatileState=@("fiscal.sqlite3","fiscal.sqlite3-wal","fiscal.sqlite3-shm","admin-token.txt","zoneinfo")
    failure=$(Safe-Detail $Failure)
    checks=$checks
  } | ConvertTo-Json -Depth 6 | Set-Content $EvidencePath -Encoding UTF8
}
function Normalize-Thumbprint([string]$Value) {
  return ($Value -replace '\s','').ToUpperInvariant()
}
function Expand-Package([string]$InputPath,[string]$Name) {
  $resolved = (Resolve-Path $InputPath).Path
  if (Test-Path $resolved -PathType Container) { return $resolved }
  if ([IO.Path]::GetExtension($resolved) -ne ".zip") { throw "$Name package must be a directory or ZIP." }
  $target = Join-Path $workRoot $Name
  New-Item -ItemType Directory -Force -Path $target | Out-Null
  Expand-Archive -LiteralPath $resolved -DestinationPath $target -Force
  return $target
}
function Read-Package([string]$Root,[string]$ExpectedThumbprint,[string]$Label) {
  $manifestPath = Join-Path $Root "release-manifest.json"
  $exePath = Join-Path $Root "Bookie-Local-Gateway.exe"
  $installScript = Join-Path $Root "install.ps1"
  $verifyScript = Join-Path $Root "verify-windows-install.ps1"
  foreach ($required in @($manifestPath,$exePath,$installScript,$verifyScript)) {
    if (-not (Test-Path $required -PathType Leaf)) { throw "$Label package is missing $([IO.Path]::GetFileName($required))." }
  }
  $manifest = Get-Content $manifestPath -Raw | ConvertFrom-Json
  $expected = Normalize-Thumbprint $ExpectedThumbprint
  if ($manifest.productionAllowed -isnot [bool]) { throw "$Label productionAllowed must be a JSON boolean." }
  if ([string]$manifest.architecture -ne "win-x64") { throw "$Label package is not win-x64." }
  if ((Normalize-Thumbprint ([string]$manifest.signerThumbprint)) -ne $expected) {
    throw "$Label manifest signer does not match the out-of-band expected thumbprint."
  }
  $isProduction = [string]$manifest.releaseChannel -eq "internal-production" -and
    [bool]$manifest.productionAllowed -eq $true
  if (-not $isProduction) {
    throw "$Label must be an internal-production package. TEST ONLY packages are not supported by this privileged verifier."
  }
  $expectedSubject = "CN=Bookie Local Gateway BOOKIE INTERNAL PRODUCTION"
  if ([string]$manifest.signerSubject -ne $expectedSubject) { throw "$Label manifest signer subject is invalid." }
  if (-not $manifest.manifestException) { throw "$Label manifest self-hash exception is missing." }
  if (@(Get-ChildItem $Root -Directory).Count -ne 0) { throw "$Label package must contain only a flat allowlisted file set." }
  $manifestNames = @($manifest.files.PSObject.Properties | Select-Object -ExpandProperty Name)
  $actualNames = @(Get-ChildItem $Root -File | Where-Object Name -ne "release-manifest.json" |
    Select-Object -ExpandProperty Name)
  if (@(Compare-Object ($manifestNames | Sort-Object) ($actualNames | Sort-Object)).Count -ne 0) {
    throw "$Label package file set does not exactly match its manifest."
  }
  foreach ($name in $manifestNames) {
    if ($name -match '[/\\]' -or $name -in @(".","..")) { throw "$Label manifest contains an invalid file name." }
    $candidate = Join-Path $Root $name
    $candidateEntry = $manifest.files.PSObject.Properties[$name].Value
    if (-not (Test-Path $candidate -PathType Leaf) -or
        (Get-FileHash $candidate -Algorithm SHA256).Hash.ToLowerInvariant() -ne [string]$candidateEntry.sha256 -or
        (Get-Item $candidate).Length -ne [int64]$candidateEntry.length) {
      throw "$Label package hash or length mismatch: $name"
    }
  }
  $publicCertificatePath = Join-Path $Root "bookie-internal-production.cer"
  if (-not (Test-Path $publicCertificatePath -PathType Leaf)) {
    throw "$Label internal-production package is missing its public signer certificate."
  }
  $publicCertificate = [Security.Cryptography.X509Certificates.X509Certificate2]::new($publicCertificatePath)
  if ((Normalize-Thumbprint $publicCertificate.Thumbprint) -ne $expected -or
      $publicCertificate.Subject -ne $expectedSubject -or
      $publicCertificate.Issuer -ne $expectedSubject) {
    throw "$Label public signer certificate does not match the expected signer."
  }
  $signerCertificate = $publicCertificate
  $signerEku = $signerCertificate.Extensions | Where-Object { $_.Oid.Value -eq "2.5.29.37" } | Select-Object -First 1
  if (-not $signerEku -or
      @($signerEku.EnhancedKeyUsages | Where-Object Value -eq "1.3.6.1.5.5.7.3.3").Count -ne 1) {
    throw "$Label signer lacks the Code Signing EKU."
  }
  $entry = $manifest.files.'Bookie-Local-Gateway.exe'
  $exeHash = (Get-FileHash $exePath -Algorithm SHA256).Hash.ToLowerInvariant()
  if (-not $entry -or $exeHash -ne [string]$entry.sha256) { throw "$Label executable hash does not match its manifest." }
  return [ordered]@{
    Root=$Root;Manifest=$manifest;Exe=$exePath;Install=$installScript;Verify=$verifyScript
    ExeHash=$exeHash;ExpectedThumbprint=$expected;ExpectedSubject=$expectedSubject
    SignerCertificate=$signerCertificate
  }
}
function Ensure-SignerTrust([object]$Package) {
  foreach ($storeName in @("Root","TrustedPublisher")) {
    $store = [Security.Cryptography.X509Certificates.X509Store]::new($storeName,"LocalMachine")
    $store.Open("ReadWrite")
    try {
      $matches = @($store.Certificates | Where-Object {
        (Normalize-Thumbprint $_.Thumbprint) -eq $Package.ExpectedThumbprint
      })
      if ($matches.Count -gt 1) { throw "Pinned signer is duplicated in LocalMachine\$storeName." }
      if ($matches.Count -eq 0) {
        $store.Add($Package.SignerCertificate)
        $trustEntriesAdded.Add([ordered]@{Store=$storeName;Thumbprint=$Package.ExpectedThumbprint})
      }
    } finally { $store.Close() }
  }
}
function Remove-HarnessTrust {
  foreach ($entry in @($trustEntriesAdded)) {
    $store = [Security.Cryptography.X509Certificates.X509Store]::new([string]$entry.Store,"LocalMachine")
    $store.Open("ReadWrite")
    try {
      foreach ($certificate in @($store.Certificates | Where-Object {
        (Normalize-Thumbprint $_.Thumbprint) -eq [string]$entry.Thumbprint
      })) { $store.Remove($certificate) }
    } finally { $store.Close() }
  }
  $trustEntriesAdded.Clear()
}
function Assert-PackageSignatures([object]$Package,[string]$Label) {
  $signedFiles = @($Package.Exe)
  $signedFiles += @(Get-ChildItem $Package.Root -File -Filter "*.ps1" | Select-Object -ExpandProperty FullName)
  foreach ($path in $signedFiles) {
    $signature = Get-AuthenticodeSignature $path
    if ($signature.Status -ne "Valid" -or -not $signature.SignerCertificate -or
        (Normalize-Thumbprint $signature.SignerCertificate.Thumbprint) -ne $Package.ExpectedThumbprint -or
        $signature.SignerCertificate.Subject -ne $Package.ExpectedSubject -or
        $signature.SignerCertificate.Issuer -ne $Package.ExpectedSubject) {
      throw "$Label package Authenticode validation failed after pinned trust bootstrap: $([IO.Path]::GetFileName($path))."
    }
  }
}
function Get-SafeChildDiagnostic([string]$Output) {
  $rules = [ordered]@{
    "Authenticode signer certificate is missing"="AUTHENTICODE_SIGNER_MISSING"
    "Authenticode signature is cryptographically invalid before trust installation"="AUTHENTICODE_PRETRUST_STATUS_INVALID"
    "Pre-trust signer thumbprint mismatch"="AUTHENTICODE_PRETRUST_THUMBPRINT_MISMATCH"
    "Authenticode signature is not Valid"="AUTHENTICODE_POSTTRUST_STATUS_INVALID"
    "Signer thumbprint mismatch"="AUTHENTICODE_SIGNER_THUMBPRINT_MISMATCH"
    "RFC3161 timestamp is missing"="AUTHENTICODE_TIMESTAMP_MISSING"
    "EXE/script signer binding failed|Packaged script signer does not match"="AUTHENTICODE_SIGNER_BINDING_FAILED"
    "Production signer classification failed|Manifest classification does not match actual signer classification"="AUTHENTICODE_SIGNER_CLASSIFICATION_FAILED"
    "Packaged public signer certificate does not match the manifest"="PUBLIC_CERTIFICATE_MANIFEST_MISMATCH"
    "Packaged public signer certificate does not match ExpectedSignerThumbprint"="PUBLIC_CERTIFICATE_THUMBPRINT_MISMATCH"
    "Packaged public signer certificate lacks the Code Signing EKU"="PUBLIC_CERTIFICATE_EKU_MISSING"
    "manifest|package file set|hash mismatch|version fields"="PACKAGE_VALIDATION_FAILED"
    "CreateServiceW|ChangeServiceConfigW|ChangeServiceConfig2W|SCM ImagePath|SCM registry"="SCM_CONFIGURATION_FAILED"
    "Sensitive ACL|unexpected ACE|ACL target"="ACL_VALIDATION_FAILED"
    "firewall"="FIREWALL_CONFIGURATION_FAILED"
    "Staged executable|atomic replacement|Installed executable"="EXECUTABLE_REPLACEMENT_FAILED"
    "Europe/Ljubljana|TZif|timezone"="TIMEZONE_INSTALL_FAILED"
    "Gateway service did not reach Running|start Windows service"="SERVICE_START_FAILED"
    "Gateway health check failed|check gateway health"="HEALTH_CHECK_FAILED"
    "Access is denied|requested registry access is not allowed"="WINDOWS_ACCESS_DENIED"
    "cannot find|could not find|does not exist|is missing"="REQUIRED_RESOURCE_MISSING"
    "FATAL ROLLBACK ERROR"="INSTALL_AND_ROLLBACK_FAILED"
    "Installation failed during 'prepare existing installation'"="PREPARE_INSTALLATION_FAILED"
    "Installation failed during 'change Windows service configuration'"="SERVICE_CHANGE_FAILED"
    "Installation failed during 'create Windows service and recovery configuration'"="SERVICE_CREATE_FAILED"
    "Installation failed during 'verify Windows service ImagePath'"="SERVICE_IMAGE_PATH_VERIFICATION_FAILED"
    "Installation failed during 'configure Windows service recovery'"="SERVICE_RECOVERY_CONFIGURATION_FAILED"
    "Installation failed during 'start Windows service'"="SERVICE_START_FAILED"
    "Installation failed during 'check gateway health'"="HEALTH_CHECK_FAILED"
  }
  foreach ($rule in $rules.GetEnumerator()) {
    if ($Output -match [string]$rule.Key) { return [string]$rule.Value }
  }
  return "UNCLASSIFIED_CHILD_FAILURE"
}
function Invoke-PowerShell([string]$Script,[string[]]$Arguments,[bool]$ExpectFailure,[string]$Phase) {
  $hostExe = (Get-Command powershell.exe -ErrorAction Stop).Source
  $allArguments = @("-NoProfile","-ExecutionPolicy","Bypass","-File",$Script) + $Arguments
  $previousPreference = $ErrorActionPreference
  $ErrorActionPreference = "Continue"
  try {
    $output = @(& $hostExe @allArguments 2>&1)
    $exitCode = $LASTEXITCODE
  } finally { $ErrorActionPreference = $previousPreference }
  if ($ExpectFailure) {
    if ($exitCode -eq 0) { throw "The intentionally failed installer unexpectedly succeeded in phase $Phase." }
  } elseif ($exitCode -ne 0) {
    $diagnostic = Get-SafeChildDiagnostic ($output | Out-String)
    throw "Verified PowerShell child phase $Phase failed with exit $exitCode ($diagnostic). Raw child output was withheld from evidence."
  }
  return [ordered]@{ExitCode=$exitCode;Output=($output | Out-String)}
}
function Installer-Arguments([object]$Package,[bool]$Upgrade) {
  $arguments = @("-ExpectedSignerThumbprint",$Package.ExpectedThumbprint,"-InstallPath",$InstallPath,"-Port",[string]$Port)
  if ($Upgrade) { $arguments += "-ConfirmSafeCloudRelease" }
  return $arguments
}
function Get-Health {
  $response = Invoke-WebRequest -UseBasicParsing -Uri "http://127.0.0.1`:$Port/v1/gateway/health" -TimeoutSec 10
  if ([int]$response.StatusCode -ne 200) { throw "Gateway health did not return HTTP 200." }
  return ($response.Content | ConvertFrom-Json)
}
function Read-AdminToken {
  if (-not (Test-Path $adminTokenPath -PathType Leaf)) { throw "Admin token file is missing." }
  $token = [IO.File]::ReadAllText($adminTokenPath).Trim()
  if (-not $token) { throw "Admin token file is empty." }
  return $token
}
function Get-DeviceProofFingerprint([string]$AdminToken) {
  $random = New-Object byte[] 32
  [Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($random)
  $challenge = [Convert]::ToBase64String($random).TrimEnd("=").Replace("+","-").Replace("/","_")
  $body = @{challengeId=[Guid]::NewGuid().ToString();challenge=$challenge} | ConvertTo-Json -Compress
  $proof = Invoke-RestMethod -Method Post -Uri "http://127.0.0.1`:$Port/v1/provisioning/proof" `
    -Headers @{"X-Bookie-Admin-Token"=$AdminToken} -ContentType "application/json" -Body $body -TimeoutSec 10
  if ([string]$proof.keyFingerprintSha256 -notmatch '^[a-f0-9]{64}$') {
    throw "Provisioning proof did not return a valid device fingerprint."
  }
  return [string]$proof.keyFingerprintSha256
}
function Get-StableDataManifest {
  $items = @()
  if (-not (Test-Path $dataPath)) { return $items }
  foreach ($file in @(Get-ChildItem $dataPath -File -Recurse)) {
    $relative = $file.FullName.Substring($dataPath.TrimEnd('\').Length).TrimStart('\')
    $leaf = $file.Name.ToLowerInvariant()
    if ($leaf -in @("fiscal.sqlite3","fiscal.sqlite3-wal","fiscal.sqlite3-shm","admin-token.txt") -or
        $relative -like "zoneinfo\*") { continue }
    $items += "$relative|$((Get-FileHash $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant())|$($file.Length)"
  }
  return @($items | Sort-Object)
}
function Same-Manifest([string[]]$Left,[string[]]$Right) {
  return @(Compare-Object @($Left) @($Right)).Count -eq 0
}
function Assert-ScmContract([string]$Installer) {
  $source = Get-Content $Installer -Raw
  $official = $source.Contains("CreateService(") -and $source.Contains("ChangeServiceConfig(") -and
    $source.Contains("ChangeServiceConfig2(") -and -not $source.Contains('sc.exe" @("create"') -and
    -not $source.Contains('sc.exe" @("config"') -and -not $source.Contains("New-Service") -and
    -not $source.Contains("Set-Service")
  Add-Check "Official SCM APIs only" $official "CreateServiceW/ChangeServiceConfigW/ChangeServiceConfig2W contract"
}
function Assert-PostReplaceFailureContract([string]$Installer) {
  $source = Get-Content $Installer -Raw
  $replaceAt = $source.IndexOf("[IO.File]::Replace")
  $testFailureAt = $source.IndexOf("Existing service has unsupported custom Environment entries")
  Add-Check "Forced failure occurs after atomic replace" ($replaceAt -ge 0 -and $testFailureAt -gt $replaceAt) `
    "unsupported Environment guard follows File.Replace"
}

try {
  if (-not $ConfirmFencedLab) {
    throw "This test replaces a Windows service and intentionally triggers rollback. Use a clean fenced lab and pass -ConfirmFencedLab."
  }
  if (-not [Environment]::Is64BitOperatingSystem) { throw "Windows x64 is required." }
  if (Get-Service BookieFiscalService -ErrorAction SilentlyContinue) { throw "Clean-lab precondition failed: service already exists." }
  foreach ($path in @($InstallPath,$dataPath,$backupPath)) {
    if (Test-Path $path) { throw "Clean-lab precondition failed: a prior gateway path exists." }
  }
  New-Item -ItemType Directory -Force -Path $workRoot | Out-Null
  $previousRoot = Expand-Package $PreviousPackagePath "previous"
  $newRoot = Expand-Package $NewPackagePath "new"
  $previous = Read-Package $previousRoot $ExpectedPreviousSignerThumbprint "Previous"
  $new = Read-Package $newRoot $ExpectedNewSignerThumbprint "New"
  $release.previous = [string]$previous.Manifest.productVersion
  $release.new = [string]$new.Manifest.productVersion
  Add-Check "Clean Windows lab" $true "service, install, ProgramData and backup paths absent"
  Add-Check "Distinct signed executables" ($previous.ExeHash -ne $new.ExeHash) "old and new SHA-256 differ"
  Ensure-SignerTrust $previous
  Ensure-SignerTrust $new
  Assert-PackageSignatures $previous "Previous"
  Assert-PackageSignatures $new "New"
  Add-Check "Pinned Authenticode validation" $true "all EXE and PowerShell signatures are Valid after exact signer trust bootstrap"
  Assert-ScmContract $previous.Install
  Assert-ScmContract $new.Install
  Assert-PostReplaceFailureContract $new.Install

  Invoke-PowerShell $previous.Install (Installer-Arguments $previous $false) $false "previous-install" | Out-Null
  $initialHealth = Get-Health
  Add-Check "Previous package health" ([string]$initialHealth.status -eq "ok") "HTTP 200 and status ok"
  $initialToken = Read-AdminToken
  $initialFingerprint = Get-DeviceProofFingerprint $initialToken
  $initialStableManifest = @(Get-StableDataManifest)
  $previousInstalledHash = (Get-FileHash (Join-Path $InstallPath "Bookie-Local-Gateway.exe") -Algorithm SHA256).Hash.ToLowerInvariant()
  Add-Check "Previous executable installed" ($previousInstalledHash -eq $previous.ExeHash) "installed SHA-256 matches previous package"
  Add-Check "Persistent device state created" ([bool]$initialFingerprint) "device proof key and protected admin identity exist"

  New-ItemProperty -Path $serviceRegistryPath -Name Environment -PropertyType MultiString `
    -Value @("BOOKIE_UPGRADE_ROLLBACK_TEST=1") -Force | Out-Null
  $testEnvironmentAdded = $true
  $failedUpgrade = Invoke-PowerShell $new.Install (Installer-Arguments $new $true) $true "intentional-rollback"
  $expectedFailure = $failedUpgrade.Output -match "unsupported custom Environment entries" -and
    $failedUpgrade.Output -match "Rollback succeeded"
  Add-Check "Intentional post-replace rollback" $expectedFailure "installer rejected test Environment and reported successful rollback"
  Remove-ItemProperty -Path $serviceRegistryPath -Name Environment -ErrorAction Stop
  $testEnvironmentAdded = $false

  $rollbackHash = (Get-FileHash (Join-Path $InstallPath "Bookie-Local-Gateway.exe") -Algorithm SHA256).Hash.ToLowerInvariant()
  $rollbackHealth = Get-Health
  $rollbackToken = Read-AdminToken
  $rollbackFingerprint = Get-DeviceProofFingerprint $rollbackToken
  $rollbackStableManifest = @(Get-StableDataManifest)
  Add-Check "Rollback restored previous executable" ($rollbackHash -eq $previous.ExeHash) "previous executable SHA-256 restored"
  Add-Check "Rollback health" ([string]$rollbackHealth.status -eq "ok") "previous service returned HTTP 200"
  Add-Check "Rollback preserved admin identity" ($rollbackToken -ceq $initialToken) "token compared only in memory"
  Add-Check "Rollback preserved device identity" ($rollbackFingerprint -ceq $initialFingerprint) "device proof fingerprint unchanged"
  Add-Check "Rollback preserved stable ProgramData" (Same-Manifest $initialStableManifest $rollbackStableManifest) `
    "volatile SQLite/WAL, token and release-managed timezone files excluded"

  Invoke-PowerShell $new.Install (Installer-Arguments $new $true) $false "successful-upgrade" | Out-Null
  $upgradedHash = (Get-FileHash (Join-Path $InstallPath "Bookie-Local-Gateway.exe") -Algorithm SHA256).Hash.ToLowerInvariant()
  $upgradedHealth = Get-Health
  $upgradedToken = Read-AdminToken
  $upgradedFingerprint = Get-DeviceProofFingerprint $upgradedToken
  $upgradedStableManifest = @(Get-StableDataManifest)
  Add-Check "Atomic upgrade installed new executable" ($upgradedHash -eq $new.ExeHash) "installed SHA-256 matches new package"
  Add-Check "Upgraded gateway health" ([string]$upgradedHealth.status -eq "ok") "new service returned HTTP 200"
  Add-Check "Upgrade preserved admin identity" ($upgradedToken -ceq $initialToken) "token compared only in memory"
  Add-Check "Upgrade preserved device identity" ($upgradedFingerprint -ceq $initialFingerprint) "device proof fingerprint unchanged"
  Add-Check "Upgrade preserved stable ProgramData" (Same-Manifest $initialStableManifest $upgradedStableManifest) `
    "no false differences from active SQLite/WAL or token files"

  $verifyArgs = @("-ExpectedSignerThumbprint",$new.ExpectedThumbprint,"-InstallPath",$InstallPath,
    "-Port",[string]$Port,"-EvidencePath",(Join-Path (Split-Path $EvidencePath -Parent) "windows-install-after-upgrade.json"))
  Invoke-PowerShell $new.Verify $verifyArgs $false "final-verification" | Out-Null
  Add-Check "Final Windows installation verification" $true "Authenticode, SCM, ACL, firewall and health verifier passed"
  Write-Evidence "passed"
  Write-Host "Windows gateway rollback and signed-package upgrade verified. Evidence: $EvidencePath"
} catch {
  $failure = $_.Exception.Message
  if ($testEnvironmentAdded -and (Test-Path $serviceRegistryPath)) {
    Remove-ItemProperty -Path $serviceRegistryPath -Name Environment -ErrorAction SilentlyContinue
  }
  Remove-HarnessTrust
  $checks.Add([ordered]@{name="verification";status="failed";detail=(Safe-Detail $failure)})
  Write-Evidence "failed" $failure
  throw
} finally {
  if (Test-Path $workRoot) { Remove-Item $workRoot -Recurse -Force -ErrorAction SilentlyContinue }
}