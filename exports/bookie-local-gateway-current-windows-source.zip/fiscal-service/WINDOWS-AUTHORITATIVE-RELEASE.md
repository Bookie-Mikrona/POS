# Avtoritativni Windows release

Za interno produkcijsko različico `1.0.0` je avtoritativen samo:

- `artifacts/Bookie-Local-Gateway-1.0.0-internal-production-win-x64.zip`
- SHA-256: `28d7a639312ce6536f1e9499087c3892b7b363dc5e40d529d30f9c19d0544e51`

Sledljivost:

- `fiscal-service/windows-install-evidence.verifier.json` je nespremenjeni izhod verifierja, ki je bil dobavljen v tem ZIP-u.
- `fiscal-service/windows-install-evidence.json` temu izhodu doda identiteto ZIP-a, manifesta, EXE-ja in kanoničnih podpisanih skript.
- Vseh 41 obveznih preverjanj je potrjenih. Edini neizvedeni pregled je izbirni fizični RAW test tiskalnika.

Stare signing kite, unsigned pakete, neuspešne prepise in superseded podpisane ZIP-e smo odstranili, da jih ni mogoče zamenjati za izdajo.